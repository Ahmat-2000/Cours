#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int sem_create (key_t cle, int initval) {

 int semid ;
 union semun{
     int val ;  
   struct semid_ds *buf ; /* les deux champs suivants ne sont */
   ushort *array;         /* pas utilis\'es dans notre situation
        nous ne les d\'etaillons donc pas */
 } arg_ctl ;

 // On commence par cr\'eer le s\'emaphore 
 semid = semget(ftok("dijkstra.h",cle),1,IPC_CREAT|IPC_EXCL|0666);
 if (semid == -1){
   semid = semget(ftok("dijkstra.h",cle),1,0666) ;
   if (semid == -1) {
      perror("Erreur semget()") ;
      exit(1) ;
   }
 }
 /* dans le code ci-dessus, l'instruction ftok("dijkstra.h",cle)
  * permet d'obtenir une clef assurant que l'appel semget fournit
  * l'identificateur semid du s\'emaphore \`a
  * partir de la connaissance de la cl\'e cle et de la cha\^\i{}ne
  * de caract\`eres "dijstra.h". Ainsi, deux processus sans liens
  * de parent\'e peuvent utiliser le m\^eme s\'emaphore \`a condition
  * de conna\^\i{}tre la cl\'e et la cha\^\i{}ne de caract\`eres */

 // Maintenant on affecte une valeur initiale au s\'emaphore
 arg_ctl.val = initval ;
 if (semctl(semid,0,SETVAL,arg_ctl) == -1){
    perror("Erreur lors de l'initialisation du semaphore") ;
    exit(1) ;
        }

 printf("On cr\\'ee un s\\'emaphore dont le num\\'ero est %d\n",semid) ;

 return semid ;
}

/*  la valeur du s\'emaphore est d\'ecr\'ement\'ee de 1 s'il est diff\'erent
 *  de 0 sinon, le processus appelant est bloqu\'e et est plac\'e dans une 
 *  file d'attente li\'ee au s\'emaphore */

void down(int semid) {

  struct sembuf sempar ;

  sempar.sem_num = 0 ;
  sempar.sem_op = -1 ;
  sempar.sem_flg = 0 ;

  if ( semop(semid,&sempar,1) == -1)
    perror("Erreur lors du down") ;
}

/* la valeur du semaphore est incremente de 1 s'il n'y a pas de processus  
   dans la file d'attente sinon, s reste inchangee et on libere le premier  
   processus de la file d'attente */

void up(int semid) {

  struct sembuf sempar ;

  sempar.sem_num = 0 ;
  sempar.sem_op = 1 ;
  sempar.sem_flg = 0 ;

  if (semop(semid,&sempar,1) ==-1)
    perror("Erreur lors du up") ;
}

void sem_delete(int semid){

  printf("destruction du s\\'emaphore %d\n",semid) ;

  if(semctl(semid,0,IPC_RMID,0) == -1)
    perror("Erreur lors de la destruction du semaphore") ;
}

