#include "omp_solve_n_queens_v1.h"

unsigned long
omp_solve_n_queens_v1(const int dim) {

  // Nombre de solutions.
  unsigned long how_many = 0;

  /***********************
   * ... à compléter ... *
   ***********************/
  
  // C'est terminé.
  return how_many;
  
}
