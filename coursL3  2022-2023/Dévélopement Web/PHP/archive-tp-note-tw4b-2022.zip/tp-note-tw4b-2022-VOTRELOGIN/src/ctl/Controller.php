<?php


/* Inclusion des classes nécessaires */
require_once("model/Comm.php");
require_once("model/CommStorage.php");
require_once("model/CommBuilder.php");
require_once("view/MainView.php");


class Controller {

	protected $v;
	protected $commStorage;

	public function __construct(MainView $view, CommStorage $commStorage) {
		$this->v = $view;
		$this->commStorage = $commStorage;
	}

	public function listPage() {
		$comms = $this->commStorage->readAll();
		$this->v->makeListPage($comms);
	}

	public function newCommPage() {
		/*
 		 * À COMPLÉTER
 		 */
		throw new Exception("Not yet implemented");
	}

	public function saveNewComm(array $data) {
		/*
 		 * À COMPLÉTER
 		 */
		throw new Exception("Not yet implemented");
	}

}

?>
