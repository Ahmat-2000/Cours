def graphe_cavalier(grille):
    pass

def distance_cavalier(grille,p):
    pass
