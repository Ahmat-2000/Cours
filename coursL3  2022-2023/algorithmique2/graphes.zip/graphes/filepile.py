class FilePile:
    class Element:
        # TODO : la classe element contient un maillon de la liste
        # chaînée 
        def __init__(self, precedent, prochain, contenu):
            pass
    def __init__(self):
    # Une file/pile sera toujours vide à l'initialisation
        self.start = None
        self.end = None
    def pop(self):
        # récupère le premier élément de la liste chaînée
        # en l'enlevant de celle-ci
        pass
    def pushFirst(self,contenu):
        #insère au début de la liste chaînée
        pass
    def pushLast(self,contenu):
        #insère à la fin de la liste chaînée
        pass
    def __iter__(self):
        # (bonus) On pourra définir un itérateur sur notre liste
        pass

if __name__=="__main__":
# On peut écrire des tests ici, ceux-ci seront executés
# si on appelle ce fichier directement avec python graphe.py
# mais ne le seront pas lors d'un import 
    pass

