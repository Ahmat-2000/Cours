from shared import Commit, liste_objets # NE PAS SUPPRIMER CETTE LIGNE

#######################################################################

# Ecrivez votre réponses ci-dessous en complétant les fonctions
# Si vous voulez écrire vos propres tests, écrivez-les à la fin du fichier,
# dans la partie if __name__="__main__" et testez votre code en cliquant sur
# la "fusée" (bouton "executer", pas "evaluer")

### Git bissect
## Commits et branches
def branche(i,j):
    pass

## Git bissect
def git_bissect(branche):
    pass


### Problème du sac à dos
## Version exacte : programmation dynamique
def dyn_KP(liste,P):
    pass

def sol_KP(liste,P):
    pass

## Approximation
def fusion_eff(liste1,liste2):
    pass

def tri_eff(liste):
    pass

## Version exacte : backtracking
def approx_KP(liste,P):
    pass

def back_KP(liste,P):
    pass

if __name__=="__main__":
    ## Testez vos functions ici:
    pass