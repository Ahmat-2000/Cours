# coding: utf8
# Ecrivez votre programme ci-dessous.
# Bouton Fullscreen pour passer en plein ecran
# Ensuite Save + Run puis Save + Evaluate

import os
import math
from noeud import *


################################################    
###                                          ###
### Implémentez ici les fonctions demandées  ###
###                                          ###
################################################    

#
# arbre_exemple()
#

def arbre_exemple():
    """
    Fonction qui retourne un noeud qui correspond à la racine
    de l'arbre donné dans le sujet. 
    """
    return None


#
# construire_tableau_noeuds(texte)
#

def construire_tableau_noeuds(texte):
    """
    Fonction qui lit dans le texte passé en paramètre
    tous les symboles présents dans le texte.
    La fonction retourne une paire constituée respectivement par:
        - le nombre total de caractères dans le texte;
        - un tableau de noeuds où chaque noeud correspond à un symbole
        présent dans le texte. Le nombre d'occurrences du symbole est
        enregistré dans le champs nb_occur du noeud. Les noeuds n'ont pas
        de fils droite et gauche (les champs sont à None). La fréquence
        des noeuds (champs freq) est mis à 0.0. Les noeuds sont également
        ordonnés par ordre décroissant.
    Autrement dit, la fonction retourne un tableau ordonné de noeuds
    correspondant aux noeuds du Pas 1 dans l'exemple si le texte est
    "AAAAAAEEEEEEEEIIIIIOOOUU" (compatible avec les nombres d'occurrences
    donnés dans l'exemple). 
    """
    return 0, []


#
# frequence(tab_noeud,nb_symboles)
#

def frequence(tab_noeud,n):
    """
    Fonction prenant en paramètres un tableau de noeuds (tab_noeud) et un
    entier n et qui remplace toutes les fréquences des noeuds présents
    dans le tableau par nb_occur/n, nb_occur étant le champs du même nom
    dans les noeuds du tableau.
    La fonction ne retourne aucune valeur.
    """
    return


#
# calcul de l'entropie
#

def calcule_entropie(tab_noeud):
    """
    Calcule l'entropie associée aux fréquences des noeuds du tableau de noeuds
    tab_noeud passé en paramètre.
    """ 
    return 0.0


#
#Construction de l'arbre de Huffman
#

def construit_arbre_huffman(tab_noeud):
    """
    Fonction qui construit l'arbre de Huffman à partir des noeuds
    présents dans le tableau tab_noeud qui recensent toutes les lettres
    ainsi que leurs fréquences. La fonction retourne le noeud
    correspondant à la racine de l'arbre.
    Contrainte: en cas d'égalité des fréquences, le nouveau noeud créé à
    chaque étape doit être placé après les noeuds existant et ayant la même
    fréquence.
    """
    return None


#
# construction du dictionnaire à partir d'un arbre de Huffman
#

def construit_dico_huffman(arbre,prefixe,dico):
    """
    Construit un dictionnaire dont les clés sont les lettres situées aux
    feuilles de l'arbre passé en paramètre. La valeur associée à une lettre
    (une clé) est le chemin de la racine à la feuille (0 vers la gauche,
    1 vers la droite) préfixé par le préfixe passé en paramètre.

    Lorsque le paramètre préfixe est la chaîne vide prefixe='', le code
    obtenu est le code de Huffman définit par l'arbre.

    Cette fonction peut être implémentée très simplement de façon récursive.
    """
    return

#
# Calcul de la longueur moyenne d'un code à partir de l'arbre
#

def longueur_moyenne(arbre,h=0):
    """
    calcule la longueur moyenne d'un code de Huffman donné par
    son arbre de Huffman.
    """
    return -1.0

#
#Codage du fichier
#

def codage(chaine, dico_codage):
    """
    Encode la chaine passée en paramètre à l'aide du dictionnaire
    dico_codage. La fonction retourne la chaine encodée et le
    taux de compression=
        nb de bits de la chaine initiale/nb de bits de la chaine codée.
    On considèrera que chaque caractère est codé sur 8 bits dans la chaîne
    initiale.
    """
    return "" , 0.0

################################################    
###                                          ###
### Programme principal                      ###
###                                          ###
################################################   

if __name__=="__main__": # NE PAS SUPPRIMER CETTE LIGNE
    # Votre programme principal ne sera pas evalue.
    # Utilisez-le pour tester votre programme en faisant
    # les appels de votre choix.
    # Respectez bien ce niveau d'indentation.
    print("Debut du programme principal")
    # question 1: arbre de Huffman de l'exemple
    print("********************")
    print(arbre_exemple())
    print(str_arbre(arbre_exemple()))

    # chargement des différents textes possibles
    print("********************")
    texte = "Huffman"
    #texte = "AAAAAAEEEEEEEEIIIIIOOOUU"
    #texte = fichier_to_string("Huffman.txt")
    print("Texte=",texte)

    
    # question 2: construction du tableau de noeuds initial
    print("********************")
    longueur, tab_noeuds =  construire_tableau_noeuds(texte)
    print(longueur,":",tab_noeuds)

    #question 3: mise à jour des fréquences
    print("********************")
    frequence(tab_noeuds,longueur)
    print("longueur=",longueur)
    print("tab=",tab_noeuds)

    #question 4: calcul de l'entropie    
    print("********************")
    h=calcule_entropie(tab_noeuds)
    print("entopie=",h)

    #question 5: construction de l'arbre de Huffman    
    print("********************")
    arbre=construit_arbre_huffman(tab_noeuds)
    print("arbre=",arbre)
    print(str_arbre(arbre))

    #question 6: dictionnaire pour le code Huffman    
    print("********************")
    dico={}
    construit_dico_huffman(arbre,"",dico)
    print("dico=",dico)

    #question 7: longueur moyenne d'un code Huffman    
    print("********************")
    lm=longueur_moyenne(arbre)
    print(lm)
    print("Premier théorème de Shannon? ",lm>=h and lm < h+1)
    print("Efficacité = entropie/longueur moyenne = ",h/lm)

    #question 8: encodage d'une chaîne    
    print("********************")
    chaine_encodee,taux = codage(texte,dico)
    print("chaîne encodée : ",chaine_encodee)
    print("taux de compression : ", taux)
    
    
