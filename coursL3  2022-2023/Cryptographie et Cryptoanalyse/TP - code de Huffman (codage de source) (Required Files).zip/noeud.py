# coding: utf8
# Ecrivez votre programme ci-dessous.
# Bouton Fullscreen pour passer en plein ecran
# Ensuite Save + Run puis Save + Evaluate

################################################    
###                                          ###
### Ne pas modifier le fichier               ###
###                                          ###
################################################   

import os
import math

### Fonctions fournies - ne pas modifier     ###

def fichier_to_string(nomfic):
    """
    Fonction qui retourne sous forme d'une chaîne de caractères
    le contenu du fichier dont le nom est passé en paramètre.
    """
    if not os.path.isfile(nomfic):
        return ""
    with open(nomfic,"r") as fichier:
        contenu  = fichier.read()
    return contenu[:-1]   #on enlève le dernier caractère de fin de fichier


def comparenoeuds(n1=None,n2=None):
    """
    Fonction qui teste l'égalité de deux noeuds n1 et n2 passés en paramètres.
    Attention, les deux paramètres doivent être des noeuds ou None.
    """
    if(n1==None):
        if(n2==None):
            return True
        else:
            return False
    if(n2==None):
        return False
    return n1.lettre==n2.lettre and n1.nb_occur==n2.nb_occur and n1.freq==n2.freq and comparenoeuds(n1.fils_gauche,n2.fils_gauche) and comparenoeuds(n1.fils_droite,n2.fils_droite)


def str_arbre(n=None,indent=0):
    """
    fonction récursive pour l'affichage de l'arbre de racine n
    """
    if n==None:
        return "" #"\t"*indent+"()"
    strg = str_arbre(n.fils_gauche,indent+1)
    strd = str_arbre(n.fils_droite,indent+1)
    racine = "\t"*indent+"("+n.lettre+","+str(n.nb_occur)+")"
    return strg+"\n"+racine+"\n"+strd

################################################    
###                                          ###
### Classe Noeud - ne pas modifier           ###
###                                          ###
################################################       

class Noeud:
    """
    Classe qui représente les noeuds internes et externes de l'arbre de
    codage de Huffman. Un noeud contient:
    - une lettre: si le noeud est une feuille, la lettre est un symbole du texte.
    Sinon, il s'agit d'un espace.
    - un fils gauche et droite
    - un champ nb_occur qui donne le nombre d'occurences de la lettre dans le texte
    - un champ freq qui donne la fréquence de la lettre dans le texte
    """


    """
    Constructeur pouvant prendre tous les champs comme paramètres.
    """
    def __init__(self,
                 lettre='.',
                 fils_gauche=None,
                 fils_droite=None,
                 nb_occur=0,
                 freq=0.):
        self.lettre = lettre
        self.fils_gauche = fils_gauche
        self.fils_droite = fils_droite
        self.nb_occur = nb_occur
        self.freq = freq

    """
    Fonction pour l'affichage très basique d'un noeud.
    """
    def __repr__(self):
        #return str_arbre(self)
        return "({},{},{},{},{})".format(
                self.lettre, self.fils_gauche, self.fils_droite,self.nb_occur,self.freq)
    
    
    """
    Fonction pour tester l'équalité de deux noeuds.
    """
    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return comparenoeuds(self,other)
        else:
            return False

