# coding: utf-8 # NE PAS SUPPRIMER CETTE LIGNE

"""
Classe Multigraphe
"""

class Multigraphe:
    """
    Classe qui représente les multigraphes non orientés à l'aide
    d'une matrice d'adjacence.
    La classe Multigraphe est composée de 5 champs publics:
     1/ Le champs n correspond au nombre total de sommets du multigraphe;
     2/ Le champs m correspond au nombre total d'arêtes du multigraphe;
     3/ Le champs labels est un tableau de chaînes de caractères qui liste
     tous les labels de tous les sommets. L'élément labels[i] contiendra
     le label du i-ème sommet du graphe;
     4/ Le champs adjacence est un tableau bidimensionnel à n lignes.
     La i-ème ligne est un tableau de i cases et pour j<=i, l'élément
     adjacence[i][j] est un entier correspondant au nombre d'arêtes
     entre les sommets labels[i] et labels[j]. Dans notre cas, les
     multigraphes n'ayant pas de boucle, on aura pour i=1...n,
     adjacence[i][i]=0;
     5/ le champs total est un tableau tel que total[i] est la somme
     des éléments de adjacence[i].
    """

    """
    constructeur
    """
    def __init__(self,
                 n=0,
                 m=0,
                 labels=[],
                 adjacence=[],
                 total = []):
        self.n = n
        self.m = m
        self.labels = labels
        self.adjacence = adjacence
        self.total = total

    """
    affichage d'un multigraphe
    """
    def __repr__(self):
        msg = "n="+str(self.n)+"\n"
        msg += "m="+str(self.m)+"\n"
        msg += "labels="+str(self.labels)+"\n"
        if len(self.adjacence)==0:
            msg+="[]"
        else:
            for i in range(len(self.adjacence)):
                msg += "  adjacence["+str(i)+"]="+str(self.adjacence[i])+"\n"
        msg+= "total="+str(self.total)
        return msg

    def __repr2__(self):
        msg = "Multigraphe(n="+str(self.n)+", "
        msg += "m="+str(self.m)+","
        msg += "labels="+str(self.labels)+","
        msg += "adjacence="+str(self.adjacence)+","
        msg+=  "total="+str(self.total)+")"
        print( msg)


    """
    Fonction qui duplique un multigraphe
    """
    def __duplicate__(self):
        new_labels = []
        for label in self.labels:
            new_labels.append(label)
        new_adjacence = []
        for l in self.adjacence:
            new_adjacence.append(list(l))
        new_total = list(self.total)
        return Multigraphe(n=self.n,
                           m=self.m,
                           labels=new_labels,
                           adjacence=new_adjacence,
                           total = new_total)

    """
    Fonction pour tester l'équalité de deux noeuds.
    """
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if other.n!=self.n:
            return False
        if other.m!=self.m:
            return False
        if self.total != other.total:
            return False
        if self.labels != other.labels:
            return False
        if len(self.adjacence)!=len(other.adjacence):
            return False
        for i in range(len(self.adjacence)):
            if self.adjacence[i]!=other.adjacence[i]:
                return False
        return True
    

#
# programme principal pour tester
#

if __name__ == '__main__':
    mg1 = Multigraphe()
    print("mg1=",mg1)
    mg2 = Multigraphe(n=7,m=10,labels=['1','2','3','4','5','6','7'],
                      total=[0,1,1,1,2,2,3],
                      adjacence=[[0],
                                 [1,0],
                                 [0,1,0],
                                 [0,0,1,0],
                                 [1,1,0,0,0],
                                 [0,1,0,0,1,0],
                                 [0,0,1,1,0,1,0]])
    print(mg2)
    mg3=mg2.__duplicate__()
    print("mg1==mg2 : ", mg1==mg2)
    print("mg2==mg3 : ", mg3==mg2)
    mg3.labels[0]='11111'
    print("mg2==mg3 : ", mg3==mg2)
    mg3.labels[0]='1'
    print("mg2==mg3 : ", mg3==mg2)
    mg3.adjacence[6][0]+=1
    print("mg2==mg3 : ", mg3==mg2)
    mg3.adjacence[6][0]-=1
    print("mg2==mg3 : ", mg3==mg2)
        
    
    
