# coding: utf-8 # NE PAS SUPPRIMER CETTE LIGNE

###########################
# Nom binôme 1:
# Nom binôme 2:
###########################


import math
import random
import time
from multigraphe import *


# Ecrivez vos fonctions ici


#
# question 1
#

def get_n(epsilon,certitude):
    return -1

#
# question 2
#

def estime_pisur4(epsilon,certitude):
    return 0.0

#
# question 3
#

def select_mediane_tri(S):
    return 0

#
# question 4
#

def select_mediane_procedure(S):
    return 0

#
#question 5
#

def select_mediane_vegas(S):
    return 0

#
# question 6
#

def QuickSelect(S):
    return None


#
# question 7
#

def compare_algos(n,k):
    return 0,0,0


#
# question 8 : random_multi
#

def random_multi(m,n):
    return Multigraphe()


def illustration_multi():
    return Multigraphe()

                        


#
# question 9: contraction
#

def contraction(multi,i,j):
    return    
#
# question 10: random_arete
#

def random_arete(multi):
    return -1,-1

#
# question 11: Karger
#

def karger(multi):
    return -1

#
# question 12:karger_certitude
#

def karger_certitude(multi,certitude):
    return Multigraphe()

########################################################
# Programme principal et tests des fonctions
########################################################


def test_get_n():
    print("****** question 1: get_n ******")
    for epsilon in [0.1,0.01,0.001,0.0001]:
        for certitude in [0.85,0.9,0.95]:
            print("(",epsilon,",",certitude,",",get_n(epsilon,certitude),"),",end="")
            
    print("get_n(0.1,0.95)=",get_n(0.1,0.95))
    print("get_n(0.01,0.95)=",get_n(0.01,0.95))
    print("get_n(0.001,0.95)=",get_n(0.001,0.95))


def test_estime_pisur4():
    print("****** question 2: estime_pisur4 ******")
    print("pi/4=",math.pi/4)
    print("estime_pisur4(0.1,0.95)-pi/4=",estime_pisur4(0.1,0.95)-math.pi/4)
    print("estime_pisur4(0.01,0.95)-pi/4=",estime_pisur4(0.01,0.95)-math.pi/4)
    print("estime_pisur4(0.001,0.95)-pi/4=",estime_pisur4(0.001,0.95)-math.pi/4)

def test_select_mediane_tri():
    print("****** question 3: select_mediane_tri ******")
    tab=[3,1,2]
    print("select_mediane_tri("+str(tab)+")=",select_mediane_tri(tab))
    print(tab)
    tab.append(0)
    print("select_mediane_procedure("+str(tab)+")=",select_mediane_procedure(tab))
    

def random_tab(n):
    tab=[i for i in range(n)]
    for i in range(n):
        j=random.randint(0,n-i-1)
        tab[j],tab[n-j-1] = tab[n-j-1], tab[j]
    return tab


def test_select_mediane_procedure():
    print("****** question 4: select_mediane_procedure ******")
    tab=[3]
    res= select_mediane_procedure(tab)
    while res=='ECHEC':
        res= select_mediane_procedure(tab)
        print('.',end='')
    print("select_mediane_procedure("+str(tab)+")=",res)
    print(tab)
    tab.append(0)
    print("select_mediane_procedure("+str(tab)+")=",select_mediane_procedure(tab))
    tab=random_tab(100)
    res=select_mediane_procedure(tab)
    while res=='ECHEC':
        res= select_mediane_procedure(tab)
        print('.',end='')
    print(res==select_mediane_tri(tab))
    tab=random_tab(1000)
    res=select_mediane_procedure(tab)
    while res=='ECHEC':
        res= select_mediane_procedure(tab)
        print('.',end='')
    print(res==select_mediane_tri(tab))
    
def test_select_mediane_vegas():
    print("****** question 5: select_mediane_vegas ******")
    tab=[3,1,2]
    print("select_mediane_vegas("+str(tab)+")=",select_mediane_vegas(tab))
    print(tab)
    tab.append(0)
    print("select_mediane_procedure("+str(tab)+")=",select_mediane_procedure(tab))
    tab=random_tab(100)
    print(select_mediane_vegas(tab)==select_mediane_tri(tab))
    tab=random_tab(1000)
    print(select_mediane_vegas(tab)==select_mediane_tri(tab))
    
def test_QuickSelect():
    print("****** question 6: QuickSelect ******")
    tab=[3,1,2]
    print("QuickSelect("+str(tab)+")=",QuickSelect(tab))
    print(tab)
    tab.append(0)
    print("QuickSelect([3,1,2,0])=",QuickSelect(tab))
    tab=random_tab(100)
    print(QuickSelect(tab)==select_mediane_tri(tab))
    tab=random_tab(1000)
    print(QuickSelect(tab)==select_mediane_tri(tab))

def test_compare_algos():
    print("****** question 7: compare_algos ******")
    n=10**6
    k=1
    res = compare_algos(n,k)
    print("n=",n,"   k=",k,":",res[0]>res[1]," - ",res[0]>res[2])

def test_random_multi():
    print("****** question 8: random_multi ******")
    print(random_multi(15,5))
    print(illustration_multi())

def test_contraction():
    print("****** question 9: contraction ******")
    mg=illustration_multi()
    mg.__repr2__()
    contraction(mg,1,5) #contraction 2 et 6
    mg.__repr2__()
    contraction(mg,1,4) #contraction 2-6 et 5
    mg.__repr2__()
    contraction(mg,3,4) #contraction 4 et 7
    mg.__repr2__()
    contraction(mg,0,1) #contraction 1 et 2-6-5
    mg.__repr2__()
    contraction(mg,1,2) #contraction 3 et 4-7
    mg.__repr2__()
    
def test_random_arete():
    print("****** question 10: random_arete ******")
    mg = illustration_multi()
    for _ in range(100):
        i,j = random_arete(mg)
        if mg.adjacence[i][j] == 0:
            print("erreur,",end="")
        else:
            print(str([i,j]),",",end="")
    print("fin question 10")

def test_karger():
    print("****** question 11: karger ******")
    for _ in range(4):
        mg = illustration_multi()
        karger(mg)
        print(mg)
        print("-------")

def test_karger_certitude():
    print("****** question 12: karger_certitude ******")
    mg = illustration_multi()
    print(karger_certitude(mg,0.95))
    print("-------")

    n=20
    mg = random_multi((n-1)*n//5 ,n)
    best_mg= karger_certitude(mg,0.95)
    if best_mg.m==0:
        print("Le multigraphe initial avait ",str(best_mg.n)," composantes connexes")
    else:
        print("coupe trouvée:")
        print("E1=",best_mg.labels[0])
        print("-")
        print("E2=",best_mg.labels[1])
        print("taille=",best_mg.m)
    print("-------")
    n=10 #n doit être pair et >9
    print("Test de Karger avec deux cliques reliées par 3 arêtes")
    adj=[]
    for i in range(n//2):
        adj.append([1]*i+[0])
    for i in range(n//2):
        ligne = [0]*(n//2)+[1]*i+[0]
        adj.append(ligne)
    adj[n//2][0]=1
    adj[n//2 + 1][1]=1
    adj[n//2 + 2][2]=1
    total=[]
    for i in range(n):
        total.append(sum(adj[i]))
    labels = [str(i) for i in range(n)]
    m=sum(total)
    mg = Multigraphe(n,m,labels,adj,total)
    print(mg)
    best_mg= karger_certitude(mg,0.95)
    if best_mg.m==0:
        print("Le multigraphe initial avait ",str(best_mg.n)," composantes connexes")
    else:
        print("coupe trouvée:")
        print("E1=",best_mg.labels[0])
        print("-")
        print("E2=",best_mg.labels[1])
        print("taille=",best_mg.m)
        print(best_mg)
    print("-------")



if __name__ == '__main__':
    print("*********** début des tests **************")
    test_get_n()
    #test_estime_pisur4()
    print("random_tab(10)=",random_tab(10))
    test_select_mediane_tri()
    test_select_mediane_procedure()
    test_select_mediane_vegas()
    #test_QuickSelect()
    #test_compare_algos()
    #test_random_multi()
    #test_random_arete()
    #test_karger()
    #test_karger_certitude()
    
    

