/**
 * A package for representing houses and their price.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
package houses;
