package houses;

/**
 * A class for representing houses with a garden.
 */
public class Villa extends House {

	/** The surface of the garden of this property. */
	protected int gardenSurface;

	/**
	 * Builds a new instance.
	 * 
	 * @param address       The address of this villa
	 * @param houseSurface  The indoor surface of this villa
	 * @param gardenSurface The surface of the garden of this villa
	 */
	public Villa(String address, int houseSurface, int gardenSurface) {
		super(address, houseSurface);
		this.gardenSurface = gardenSurface;
	}

	@Override
	public float price(float basePrice) {
		float indoorPrice = super.price(basePrice);
		float gardenPrice = this.gardenSurface * basePrice / 2;
		return indoorPrice + gardenPrice;
	}

	@Override
	public String toString() {
		return "Villa of indoor surface " + super.surface + " and outdoor surface " + this.gardenSurface;
	}

}
