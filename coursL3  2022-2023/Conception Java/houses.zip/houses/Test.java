package houses;

import housestests.HouseTests;
import housestests.SimulatorTests;
import housestests.VillaTests;

/**
 * Executable class for testing package houses.
 */
public class Test {

	/**
	 * Runs the tests and logs the results to standard output.
	 * 
	 * @param args ignored
	 */
	public static void main(String[] args) {
		boolean ok = true;
		HouseTests houseTester = new HouseTests();
		ok = ok && houseTester.testGetAddress();
		ok = ok && houseTester.testPrice();
		VillaTests villaTester = new VillaTests();
		ok = ok && villaTester.testGetAddress();
		ok = ok && villaTester.testPrice();
		SimulatorTests pricesTester = new SimulatorTests();
		ok = ok && pricesTester.testPriceOneHouse();
		ok = ok && pricesTester.testPriceSet();
		System.out.println(ok ? "All tests OK" : "At least one test KO");
	}

}
