package houses;

/**
 * A class for representing houses without a garden.
 */
public class House {

	/** The address of this house. */
	protected String address;

	/** The surface of this house. */
	protected int surface;

	/**
	 * Builds a new instance.
	 * 
	 * @param address The address of this house
	 * @param surface The surface of this house
	 */
	public House(String address, int surface) {
		this.address = address;
		this.surface = surface;
	}

	/**
	 * Returns the address of this house.
	 * 
	 * @return The address of this house
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 * Returns the price of this house.
	 * 
	 * @param basePrice  The price per unit of indoor surface
	 * @return The price of this house
	 */
	public float price(float basePrice) {
		return this.surface * basePrice;
	}

	@Override
	public String toString() {
		return "House of surface " + this.surface;
	}

}
