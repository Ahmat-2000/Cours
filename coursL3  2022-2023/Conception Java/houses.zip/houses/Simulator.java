package houses;

import java.util.HashSet;

/**
 * A class for computing prices for several villas or houses at once.
 */
public class Simulator {

    /** The price per unit of indoor surface. */
    protected float basePrice;
    
    /**
     * Builds a new instance.
     * @param basePrice the price per unit of indoor surface
     */
    public Simulator (float basePrice) {
        this.basePrice = basePrice;
    }

    /**
     * Returns the price for a house (or villa).
     * @param house A house
     * @return The price for the given house
     */
    public float price (House house) {
        return house.price(this.basePrice);
    }

    /**
     * Returns the price for an array of houses (and properties). The price for such an array is defined to be the sum of the individual prices.
     * @param houses An array of houses
     * @return The price for the given array
     */
    public float price (HashSet<House> houses) {
        float res = 0;
        for (House house: houses) {
            res+= this.price(house);
        }
        return res;
    }
    
}
