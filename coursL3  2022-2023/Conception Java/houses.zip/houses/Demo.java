package houses;

import java.util.HashSet;

/**
 * An executable class for demonstrating the uses of classes and methods of this
 * package.
 */
public class Demo {

	/**
	 * Runs the demo.
	 * 
	 * @param args ignored
	 */
	public static void main(String[] args) {

		// Tax amounts
		float basePrice = 100;
		System.out.println("Price per unit of surface: " + basePrice);

		// Houses
		int houseSurface = 120;
		House house = new House("1 Main Street, London City", houseSurface);
		float housePrice = house.price(basePrice);
		System.out.println("House: " + house + ", price: " + housePrice);

		// Villas
		int villaIndoorSurface = 120;
		int villaOutdoorSurface = 770;
		Villa villa = new Villa("2 Main Street, London City", villaIndoorSurface, villaOutdoorSurface);
		float villaPrice = villa.price(basePrice);
		System.out.println("Villa: " + villa + ", price: " + villaPrice);

		// Prices
		Simulator prices = new Simulator(basePrice);
		HashSet<House> houses = new HashSet<>();
		houses.add(house);
		houses.add(villa);
		float totalPrice = prices.price(houses);
		System.out.println("Houses: " + houses);
		System.out.println("Price: " + totalPrice);

	}

}
