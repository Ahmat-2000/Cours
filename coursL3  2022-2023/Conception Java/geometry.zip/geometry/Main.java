package geometry;

import java.util.Scanner;

/**
 * Executable class for demonstrating the use of class {@link Position}.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class Main {

	/**
	 * Runs the demo.
	 * 
	 * @param args ignored
	 */
	public static void main(String[] args) {

		// Coordinates
		Position position = new Position(3, 4);
		System.out.println("Exemple de position : " + position.getRepresentation() + ".");
		Position symmetric = position.symmetricX();
		System.out.println("Symétrique de la position précédente " + "par rapport à l'axe des abscisses : "
				+ symmetric.getRepresentation() + ".");
		int deltaX = 1;
		int deltaY = 2;
		position.translate(deltaX, deltaY);
		System.out.println("La première position devient, après translation par " + "(" + deltaX + ", " + deltaY
				+ ") : " + position.getRepresentation() + ".");

		// Segments
		Position position1 = new Position(3, 4);
		Position position2 = new Position(7, 7);
		Segment segment = new Segment(position1, position2);
		System.out.println("Exemple de segment : " + segment.getRepresentation() + ".");
		System.out.println("Longueur du segment : " + segment.length());
		System.out.println("Saisir un vecteur [(x1,y1),(x2,y2)] :");
		Scanner scanner = new Scanner(System.in);
		System.out.print("x1: ");
		int x1 = scanner.nextInt();
		System.out.print("y1: ");
		int y1 = scanner.nextInt();
		System.out.print("x2: ");
		int x2 = scanner.nextInt();
		System.out.print("y2: ");
		int y2 = scanner.nextInt();
		scanner.close();
		Position otherPosition1 = new Position(x1, y1);
		Position otherPosition2 = new Position(x2, y2);
		Segment otherSegment = new Segment(otherPosition1, otherPosition2);
		System.out.println("Vous avez saisi le segment " + otherSegment.getRepresentation() + ".");
		System.out.print("Les deux segments ont ");
		if (otherSegment.length() == segment.length()) {
			System.out.println("la même longueur.");
		} else {
			System.out.println("des longueurs différentes.");
		}

	}

}
