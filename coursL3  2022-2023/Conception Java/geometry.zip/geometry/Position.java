package geometry;

/**
 * A class for representing 2D points in a discrete space (with integer
 * coordinates).
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class Position {

	/** The x-coordinate. */
	private int x;

	/** The y-coordinate. */
	private int y;

	/**
	 * Builds a new instance.
	 * 
	 * @param x The x-coordinate
	 * @param y The y-coordinate
	 */
	public Position(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Returns the x-coordinate.
	 * 
	 * @return The x-coordinate
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Returns the y-coordinate.
	 * 
	 * @return The y-coordinate
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Returns the typical mathematical representation of this position as a string.
	 * 
	 * @return The typical mathematical representation of this position as a string
	 */
	public String getRepresentation() {
		return "(" + this.x + "," + this.y + ")";
	}

	/**
	 * Return a new position, representing the symmetric of this position relative
	 * to the x-axis.
	 * 
	 * @return The symmetric of this position relative to the x-axis
	 */
	public Position symmetricX() {
		return new Position(this.x, -this.y);
	}

	/**
	 * Translates this position (in place) by a given vector.
	 * 
	 * @param deltaX The x-coordinate of the translation vector
	 * @param deltaY The y-coordinate of the translation vector
	 */
	public void translate(int deltaX, int deltaY) {
		this.x += deltaX;
		this.y += deltaY;
	}

}
