package geometry;

import geometrytests.PositionTests;
import geometrytests.SegmentTests;

/**
 * Executable class for testing this package.
 */
public class Test {

	/**
	 * Runs the tests and logs the results to standard output.
	 * 
	 * @param args ignored
	 */
	public static void main(String[] args) {
		boolean ok = true;
		PositionTests positionTester = new PositionTests();
		ok = ok && positionTester.testGetX();
		ok = ok && positionTester.testGetY();
		ok = ok && positionTester.testSymmetricX();
		ok = ok && positionTester.testTranslate();
		SegmentTests segmentTester = new SegmentTests();
		ok = ok && segmentTester.testLength();
		System.out.println(ok ? "All tests OK" : "At least one test KO");
	}

}
