/**
 * A package for simple geometric operations on points (called "positions") and
 * segments.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
package geometry;
