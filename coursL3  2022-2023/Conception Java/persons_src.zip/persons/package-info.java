/**
 * A package for demonstrating the construction of a very simple class in Java.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
package persons;
