/**
 * A package for sorting persons by their current age.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
package personsorting;
