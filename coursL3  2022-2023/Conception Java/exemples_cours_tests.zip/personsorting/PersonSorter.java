package personsorting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import persons.Person;

/**
 * A class for sorting a set of persons by increasing age.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class PersonSorter {

	/**
	 * Returns a list, ordered by increasing age, of the persons in a given set.
	 * Ties are broken arbitrarily.
	 * 
	 * @param persons A set of persons
	 * @return A list containing all the given persons, by increasing age
	 */
	public List<Person> sortedPersons(Set<Person> persons) {
		List<Person> res = new ArrayList<>();
		Set<Person> remaining = new HashSet<>(persons);
		while (!remaining.isEmpty()) {
			// Searching for the youngest person not already in res
			Person youngest = null;
			Integer minAge = null;
			for (Person p : remaining) {
				int age = p.getCurrentAge();
				if (minAge == null || p.getCurrentAge() < minAge) {
					youngest = p;
					minAge = age;
				}
			}
			res.add(youngest);
			remaining.remove(youngest);
		}
		return res;
	}

}
