package personsorting;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import persons.Person;

/**
 * A class providing tests for a {@link PersonSorter}.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class PersonSortingTester {

	/** An array of ages to test with. */
	public final static int[] AGES_1 = { 12, 30, 5, 30, 7, 75, 67, 67, 78, 102 };

	/** An array of ages to test with. */
	public final static int[] AGES_2 = { 75, 65, 65, 75, 65, 63, 78 };

	/** The instance to be tested. */
	protected PersonSorter sorter;

	/**
	 * Builds a new instance.
	 * 
	 * @param sorter The instance to be tested
	 */
	public PersonSortingTester(PersonSorter sorter) {
		this.sorter = sorter;
	}

	/**
	 * Runs all available tests on the {@link PersonSorter#sortedPersons(Set)}
	 * method of the sorter.
	 * 
	 * @param random    a random generator
	 * @param nbTests   the number of random tests to run
	 * @param nbPersons an upper bound on the number of persons to generate
	 *                  (inclusive)
	 * @param maxAge    an upper bound on the age of persons to generate (inclusive)
	 * @return true if the tests are passed, false otherwise (and then prints a
	 *         message to standard output)
	 */
	public boolean runAllTests(Random random, int nbTests, int nbPersons, int maxAge) {
		boolean ok = true;
		ok = ok && this.runLimitTests();
		ok = ok && this.runNominalTests();
		ok = ok && this.runRandomTests(random, nbTests, nbPersons, maxAge);
		return ok;
	}

	/**
	 * Runs limit tests on the {@link PersonSorter#sortedPersons(Set)} method of the
	 * sorter.
	 * 
	 * @return true if the tests are passed, false otherwise (and then prints a
	 *         message to standard output)
	 */
	public boolean runLimitTests() {
		boolean ok = true;
		ok = ok && test(Collections.emptySet());
		Person p = new MockPerson(12);
		ok = ok && test(Collections.singleton(p));
		Set<Person> sameAgePersons = new HashSet<>();
		sameAgePersons.add(new MockPerson(12));
		sameAgePersons.add(new MockPerson(12));
		sameAgePersons.add(new MockPerson(12));
		ok = ok && test(new HashSet<>(sameAgePersons));
		return ok;
	}

	/**
	 * Runs nominal tests on the {@link PersonSorter#sortedPersons(Set)} method of
	 * the sorter.
	 * 
	 * @return true if the tests are passed, false otherwise (and then prints a
	 *         message to standard output)
	 */
	public boolean runNominalTests() {
		boolean ok = true;
		ok = ok && test(AGES_1);
		ok = ok && test(AGES_2);
		return ok;
	}

	/**
	 * Runs tests on the {@link PersonSorter#sortedPersons(Set)} method of the
	 * sorter, on sets of persons with pseudorandomly sampled ages.
	 * 
	 * @param random       A pseudorandom generator
	 * @param nbTests      the number of tests to run
	 * @param maxNbPersons an upper bound on the number of persons to generate
	 *                     (inclusive)
	 * @param maxAge       an upper bound on the age of persons to generate
	 *                     (inclusive)
	 * @return true if the tests are passed, false otherwise (and then prints a
	 *         message to standard output)
	 */
	public boolean runRandomTests(Random random, int nbTests, int maxNbPersons, int maxAge) {
		for (int i = 0; i < nbTests; i++) {
			Set<Person> persons = samplePersonSet(random, maxNbPersons, maxAge);
			if (!this.test(persons)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Tests whether the sorter correctly computes the list of all persons in a
	 * given set, ordered by increasing age.
	 * 
	 * @param persons A set of persons
	 * @return true if a call to {@code sorter.persons} computes the list of all
	 *         persons in the given set, ordered by increasing age, false otherwise
	 *         (and then prints a message to standard output)
	 */
	public boolean test(Set<Person> persons) {
		return test(persons, this.sorter.sortedPersons(persons));
	}

	/**
	 * Tests whether the sorter correctly computes the list of all persons in a
	 * given set, ordered by increasing age.
	 * 
	 * @param ages An array of ages to test with
	 * @return true if a call to {@code sorter.persons} computes the list of all
	 *         persons in the set of mock persons with the given ages, ordered by
	 *         increasing age, false otherwise (and then prints a message to
	 *         standard output)
	 */
	public boolean test(int[] ages) {
		Set<Person> persons = new HashSet<>();
		for (int age : ages) {
			persons.add(new MockPerson(age));
		}
		return test(persons);
	}

	/**
	 * Tests whether a list of persons is indeed the list of all persons in a given
	 * set, ordered by increasing age.
	 * 
	 * @param persons  A set of persons
	 * @param computed A list of persons
	 * @return true if the list is the list of all persons in the given set, ordered
	 *         by increasing age, false otherwise (and then prints a message to
	 *         standard output)
	 */
	public static boolean test(Set<Person> persons, List<Person> computed) {
		if (computed.size() != persons.size() || !persons.containsAll(computed)) {
			// The ordered list does not contain the correct persons (i.e., exactly those
			// given in input)
			System.out.println(
					"Computed list does not contain the correct persons: " + computed + " (input: " + persons + ")");
			return false;
		} else {
			// The ordered list contains the correct persons, checking ordering
			Integer previous = null;
			for (Person p : computed) {
				int age = p.getCurrentAge();
				if (previous != null && age < previous) {
					System.out.println("Computed list is not correctly ordered: " + computed);
					return false;
				} else {
					previous = age;
				}
			}
			return true;
		}
	}

	/**
	 * Helper method. Samples a set of persons; the persons are mock persons with a
	 * randomly sampled age.
	 * 
	 * @param random       A pseudorandom generator
	 * @param maxNbPersons The maximum number of persons (inclusive) to generate in
	 *                     the set (the effective number is sampled pseudouniformly
	 *                     in [1..maxNbPersons])
	 * @param maxAge       The maximum age (inclusive) for a person in the set (for
	 *                     each person, the effective age is sampled pseudouniformly
	 *                     in [1..maxNbAge])
	 * @return The sampled set of persons
	 */
	public static Set<Person> samplePersonSet(Random random, int maxNbPersons, int maxAge) {
		Set<Person> res = new HashSet<>();
		int nbPersons = random.nextInt(maxNbPersons + 1); // +1 since bound is inclusive
		for (int i = 0; i < nbPersons; i++) {
			int currentAge = random.nextInt(maxAge + 1); // +1 since bound is inclusive
			res.add(new MockPerson(currentAge));
		}
		return res;
	}
}
