package personsorting;

import java.util.Random;

/**
 * An executable class for demonstrating the use of the classes in this package.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class Demo {

	/**
	 * Runs the demo.
	 * 
	 * @param args args[0] is optional; if given, it must parse to a long, used as a
	 *             seed for the random generator (otherwise a random seed is
	 *             generated and printed to standard output)
	 */
	public static void main(String[] args) {

		// Creating random generator
		Long seed = null;
		if (args.length == 0) {
			seed = new Random().nextLong();
		} else if (args.length == 1) {
			try {
				seed = Long.parseLong(args[0]);
			} catch (NumberFormatException e) {
				System.err.println("The given seed is incorrect");
				System.exit(1);
			}
		} else {
			System.err.println("Expected 0 or 1 argument (seed for random generator)");
			System.exit(1);
		}
		System.out.println("Random seed: " + seed);
		Random rand = new Random(seed);

		System.out.println("Testing PersonSorter...");
		PersonSorter sorter= new PersonSorter();
		PersonSortingTester tester= new PersonSortingTester(sorter);
		boolean ok = tester.runAllTests(rand, 1000, 500, 100);
		System.out.println(ok ? "All tests passed" : "At least one test failed");

	}

}
