package personsorting;

import persons.Person;

/**
 * A mock person for tests. Such a person has mock name, first name, and date of
 * birth, but a fixed current age.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class MockPerson extends Person {

	/** An index for all created persons to have different names. */
	private static int nbCreated = 0;

	/** The person's current age (at any moment). */
	private int currentAge;

	/**
	 * Builds a new instance.
	 * 
	 * @param currentAge The person's current age (at any moment)
	 */
	public MockPerson(int currentAge) {
		super("person #" + nbCreated + " (age " + currentAge + ")", 0, 0, 0);
		this.currentAge = currentAge;
		nbCreated++;
	}

	@Override
	public int getAge(int year, int month, int day) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getCurrentAge() {
		return this.currentAge;
	}

	@Override
	public String toString() {
		return this.getName();
	}

}
