/**
 * A package for primality checking.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
package primality;
