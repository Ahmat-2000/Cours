package primality;

/**
 * An interface for primality checking of integers.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public interface PrimalityChecker {

	/**
	 * Decides whether a given integer is prime.
	 * 
	 * @param n An integer
	 * @return true if n is prime, false otherwise
	 * @throws IllegalArgumentException If n is less than or equal to 1, since the
	 *                                  definition of primality does not apply to 0,
	 *                                  1, nor to negative numbers
	 */
	boolean isPrime(int n) throws IllegalArgumentException;

}
