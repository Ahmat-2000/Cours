package primality;

/**
 * A class which implements primality checking by checking all divisors up to
 * the square root of the given integer.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class BasicPrimalityChecker implements PrimalityChecker {

	@Override
	public boolean isPrime(int n) throws IllegalArgumentException {
		if (n < 2) {
			throw new IllegalArgumentException("Primality is not defined for integers less than 2: " + n);
		}
		double sqrt = Math.sqrt(n);
		for (int i = 2; i <= sqrt; i++) {
			if (n % i == 0) {
				// i divides n, hence n is not prime
				return false;
			}
		}
		// No integer i in [2..sqrt(n)] divides n, hence n is prime
		return true;
	}

}
