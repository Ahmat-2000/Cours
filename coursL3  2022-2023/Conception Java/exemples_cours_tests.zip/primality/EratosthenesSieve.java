package primality;

import java.util.HashSet;
import java.util.Set;

/**
 * A class which implements the Sieve of Erotosthenes for finding all prime
 * numbers up to a given number.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class EratosthenesSieve implements PrimalityChecker {

	/**
	 * Computes the set of all prime integers up to a given number.
	 * 
	 * @param max The maximum number to consider (inclusive)
	 * @return The set of all prime integers up to the given number (inclusive)
	 */
	public static Set<Integer> allPrimes(int max) {
		Set<Integer> res = new HashSet<>();
		// List of nonprime numbers
		Set<Integer> composite = new HashSet<>();
		for (int n = 2; n <= max; n++) {
			if (!composite.contains(n)) {
				res.add(n);
				for (int i = 0; true; i++) {
					int ni = n * i;
					if (ni <= max) {
						composite.add(ni);
					} else {
						break;
					}
				}
			} else {
				// The fact that n is composite will not be used any more
				composite.remove(n);
			}
		}
		return res;
	}

	@Override
	public boolean isPrime(int n) throws IllegalArgumentException {
		if (n < 2) {
			throw new IllegalArgumentException("Primality is not defined for integers less than 2: " + n);
		}
		Set<Integer> primes = EratosthenesSieve.allPrimes(n);
		return primes.contains(n);
	}

}
