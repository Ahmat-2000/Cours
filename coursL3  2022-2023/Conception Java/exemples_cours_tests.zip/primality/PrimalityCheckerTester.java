package primality;

import java.util.Random;

/**
 * A class providing unit tests for any primality checker. The typical usage is
 * to instantiate the checker to be tested, then build an instance of this class
 * with this instance, and check whether call to methods {@code runXXXTests}
 * return true.
 * 
 * @author Bruno Zanuttini, Université de Caen Normandie, France
 */
public class PrimalityCheckerTester {

	/** An array of prime numbers to test with. */
	private final static int[] PRIME_NUMBERS = { 2, 3, 5, 7, 11, 31, 22_091, 9_999_991 };

	/** An array of nonprime numbers to test with. */
	private final static int[] NONPRIME_NUMBERS = { 4, 6, 8, 9, 10, 33, 49, 14_873, 979_066, 979_067, 1_000_000 };

	/** The instance to be tested. */
	protected PrimalityChecker checker;

	/**
	 * Builds a new instance
	 * 
	 * @param checker The instance to be tested
	 */
	public PrimalityCheckerTester(PrimalityChecker checker) {
		this.checker = checker;
	}

	/**
	 * Runs all available kinds of tests.
	 * 
	 * @param random     A random generator
	 * @param nb         The number of random tests to run (see
	 *                   {@link #generateNonPrime(Random, int)})
	 * @param maxDivisor The maximum divisor which can be generated for random tests
	 *                   (see {@link #generateNonPrime(Random, int)})
	 * @return true if all tests are passed, false otherwise (and in this case
	 *         prints a message to standard output)
	 */
	public boolean runAllTests(Random random, int nb, int maxDivisor) {
		boolean ok = true;
		ok = ok && this.runNominalTests();
		ok = ok && this.runLimitTests();
		ok = ok && this.runRandomTests(random, nb, maxDivisor);
		return ok;
	}

	/**
	 * Runs nominal tests, on a predefined list of integers.
	 * 
	 * @return true if all tests are passed, false otherwise (and in this case
	 *         prints a message to standard output)
	 */
	public boolean runNominalTests() {
		boolean ok = true;
		for (int prime : PRIME_NUMBERS) {
			ok = ok && this.runTest(prime, true);
		}
		for (int prime : NONPRIME_NUMBERS) {
			ok = ok && this.runTest(prime, false);
		}
		return ok;
	}

	/**
	 * Runs limit tests (that is, on the first prime and nonprime integers).
	 * 
	 * @return true if all tests are passed, false otherwise (and in this case
	 *         prints a message to standard output)
	 */
	public boolean runLimitTests() {
		boolean ok = true;
		ok = ok && this.runTest(2, true);
		ok = ok && this.runTest(3, true);
		ok = ok && this.runTest(4, false);
		ok = ok && this.runTest(5, true);
		return ok;
	}

	/**
	 * Runs tests on randomly generated nonprime numbers. Hence this method can only
	 * check that {@code false} is indeed returned by a call to
	 * {@code checker.isPrime} on a nonprime number.
	 * 
	 * @param random     A random generator
	 * @param nb         The number of tests to run
	 * @param maxDivisor The maximum divisor which can be generated (see
	 *                   {@link #generateNonPrime(Random, int)})
	 * @return true if all tests are passed, false otherwise (and in this case
	 *         prints a message to standard output)
	 */
	public boolean runRandomTests(Random random, int nb, int maxDivisor) {
		for (int i = 0; i < nb; i++) {
			int n = this.generateNonPrime(random, maxDivisor);
			if (!this.runTest(n, false)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Pseudorandomly samples a nonprime integer. Generation proceeds by
	 * pseudorandmly sampling two integers (geq 2) and returning their product. Note
	 * that this is not a (pseudo)uniform generation, as integers with more divisors
	 * are more likely to be sampled.
	 * 
	 * @param random     A pseudorandom generator
	 * @param maxDivisor An upper bound (inclusive) on each divisor which is
	 *                   generated
	 * @return A nonprime integer
	 */
	public int generateNonPrime(Random random, int maxDivisor) {
		// If maxDivisor is 10, we want to generate a divisor in [2..10], that is, 2 + a
		// number in [0,9[
		int bound = maxDivisor - 1;
		int n1 = 2 + random.nextInt(bound);
		int n2 = 2 + random.nextInt(bound);
		return n1 * n2;
	}

	/**
	 * Helper method. Runs a test on a given integer, against a given expected
	 * result.
	 * 
	 * @param n        An integer
	 * @param expected true if the given integer is prime, false otherwise
	 * @return true if the test is passed (a call to {@code checker.isPrime} on n
	 *         computed the expected result), false otherwise (and in this case
	 *         prints a message to standard output)
	 */
	private boolean runTest(int n, boolean expected) {
		boolean computed = this.checker.isPrime(n);
		if (computed != expected) {
			System.out.println("Call to checker.isPrime returned " + computed + " on " + n + ", expected " + expected);
			return false;
		} else {
			return true;
		}
	}

}
